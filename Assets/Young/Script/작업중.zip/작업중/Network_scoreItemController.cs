using UnityEngine;

public class scoreItemController : NetworkBehaviour

{
    public int itemScore;
    public itemData data;
    GameObject stageManager;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        stageManager = GameObject.FindWithTag("StageManager");
        data.itemQuantity = 0;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!IsSpawned) return;

        NetworkObject playerNetObj = collision.GetComponent<NetworkObject>();

        if (collision.CompareTag("Player"))
        {
            stageManager.GetComponent<StageManager>().GetItem(data);
            //data.itemQuantity++;//>>���߿� �����͸� ���纻���� �޾Ƽ� ���� ���� �ʿ�
            //Debug.Log(data.itemQuantity);

            //inventory UI �߰�
            InventoryManager.Instance.AddItem(data);

            RequestDespawnItemServerRpc();
        }
    }

    [ServerRpc(RequireOwnership = false)]
    private void RequestDespawnItemServerRpc()
    {
        if (NetworkObject.IsSpawned)
        {
            NetworkObject.Despawn(true);
        }
    }
}
