using UnityEngine;
using UnityEngine.SceneManagement;
using Unity.Netcode;


public class PlayerSessionData
{
    public int currentHP;
    public int coinCount = 0;
    public int tempcoinCount = 0;
    public int DefeatCount = 0;
}

public class HistoryManager : NetworkBehaviour
{
    public static GameDataManager Instance;

    private Dictionary<ulong, PlayerSessionData> sessionData = new Dictionary<ulong, PlayerSessionData>();
    public NetworkVariable<float> playTime = new NetworkVariable<float>(0f);
    public NetworkVariable<bool> isGameActive = new NetworkVariable<bool>(true);

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        if (IsServer)
        {
            if (isGameActive)
            {
                playTime += Time.deltaTime;
            }
        }
    }

    public void RegisterPlayer(ulong clientId)
    {
        if (IsServer && !sessionData.ContainsKey(clientId))
        {
            sessionData.Add(clientId, new PlayerSessionData());
        }
    }


    [ServerRpc(RequireOwnership = false)]
    public void AddDefeatCountServerRpc(ulong clientId)
    {
        if (sessionData.ContainsKey(clientId))
        {
            sessionData[clientId].defeatCount++;
        }

        ClientRpcParams clientRpcParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams { TargetClientIds = new ulong[] { clientId } }
        };
        UpdateDefeatUIClientRpc(sessionData[clientId].defeatCount, clientRpcParams);
    }
    [ClientRpc]
    private void UpdateDefeatUIClientRpc(int currentDefeatCount, ClientRpcParams clientRpcParams = default)
    {
        if (PlayerUI.Instance != null)
        {
            PlayerUI.Instance.UpdateDefeatCount(currentDefeatCount);
        }

    }

    [ServerRpc(RequireOwnership = false)]
    public void UpdateHPServerRpc(ulong clientId, int hp)
    {
        if (sessionData.ContainsKey(clientId))
        {
            sessionData[clientId].currentHP = hp;

            ClientRpcParams clientRpcParams = new ClientRpcParams
            {
                Send = new ClientRpcSendParams { TargetClientIds = new ulong[] { clientId } }
            };
            UpdateHPUIClientRpc(newHp, clientRpcParams);
        }
    }
    [ClientRpc]
    private void UpdateHPUIClientRpc(int currentHp, ClientRpcParams clientRpcParams = default)
    {
        if (PlayerUI.Instance != null)
        {
            PlayerUI.Instance.UpdateHP(currentHp);
        }
    }

    [ServerRpc(RequireOwnership = false)]
    public void AddCoinServerRpc(ulong clientId)
    {
        if (sessionData.ContainsKey(clientId))
        {
            sessionData[clientId].coinCount++;
            sessionData[clientId].tempcoinCount++;

            ClientRpcParams clientRpcParams = new ClientRpcParams
            {
                Send = new ClientRpcSendParams { TargetClientIds = new ulong[] { clientId } }
            };
            UpdateCoinUIClientRpc(sessionData[clientId].coinCount, clientRpcParams);
        }
    }
    [ClientRpc]
    private void UpdateCoinUIClientRpc(int currentCoin, ClientRpcParams clientRpcParams = default)
    {
        if (PlayerUI.Instance != null)
        {
            PlayerUI.Instance.UpdateCoin(currentCoin);
        }
    }

    public void GameClear()
    {
        isGameActive = false;
    }

    public void ResetData()
    {
        playTime = 0f;
        DefeatCount = 0;
        currentHP = 0;
        coinCount = 0;
        tempcoinCount = 0;
        isGameActive = true;
        Debug.Log("History Data Reset");
    }
}