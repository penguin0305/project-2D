using UnityEngine;
using TMPro;
using System.Collections;

public class PlayerUI : MonoBehaviour
{
    public static PlayerUI Instance;

    public TextMeshProUGUI HP;
    //public TextMeshProUGUI skillText;-��ų �߰�

    private Player player;
    //private PlayerSkill playerSkill;-��ų �߰�

    [SerializeField] private TextMeshProUGUI timerText;

    private void Awake()
    {
        // �� ȭ���� UI �ν��Ͻ��� �����Ը� �����ϹǷ� �̱������� �����մϴ�.
        if (Instance == null)
        {
            Instance = this;
        }
    }

    void UpdateHP(int currentHp)
    {
        HP.text = $"{currentHp}";
    }
    /*-��ų �߰�
    void UpdateSkillUI(int currentSkill)
    {

        skillText.text = $"{currentSkill}";
    }
    */

    private void Update()
    {
        if (timerText != null && GameDataManager.Instance != null)
        {
            UpdateTimerUI(GameDataManager.Instance.playTime.Value);
        }
    }

    private void UpdateTimerUI(float Seconds)
    {

        int minutes = Mathf.FloorToInt(Seconds / 60);
        int seconds = Mathf.FloorToInt(Seconds % 60);

        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    void OnDestroy()
    {
        if (player != null)
        {
            player.OnCheckHP -= UpdateHP;
        }
        /*-��ų �߰�
        if (playerSkill != null)
        {
            playerSkill.OnCheckSkillCount -= UpdateSkillUI;
        }
        */
    }
}